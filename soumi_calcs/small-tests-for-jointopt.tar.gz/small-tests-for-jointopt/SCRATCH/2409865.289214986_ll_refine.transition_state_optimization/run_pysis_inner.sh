#!/bin/bash

echo 'Starting YARP serial TSOPT execution...'

echo '--- Running TSOPT 1 ---'
cd /work/tsopt_run1
pysis tsopt_1_input.yaml > tsopt_1.log 2> tsopt_1.err
echo '--- Finished TSOPT 1 ---'

echo '--- Running TSOPT 2 ---'
cd /work/tsopt_run2
pysis tsopt_2_input.yaml > tsopt_2.log 2> tsopt_2.err
echo '--- Finished TSOPT 2 ---'

echo '--- Running TSOPT 3 ---'
cd /work/tsopt_run3
pysis tsopt_3_input.yaml > tsopt_3.log 2> tsopt_3.err
echo '--- Finished TSOPT 3 ---'

