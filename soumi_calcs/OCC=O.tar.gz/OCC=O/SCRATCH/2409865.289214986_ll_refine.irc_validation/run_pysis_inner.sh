#!/bin/bash

echo 'Starting YARP serial IRC execution...'

echo '--- Running IRC 1 ---'
cd /work/irc_run1
pysis irc_1_input.yaml > irc_1.log 2> irc_1.err
echo '--- Finished IRC 1 ---'

echo '--- Running IRC 2 ---'
cd /work/irc_run2
pysis irc_2_input.yaml > irc_2.log 2> irc_2.err
echo '--- Finished IRC 2 ---'

echo '--- Running IRC 3 ---'
cd /work/irc_run3
pysis irc_3_input.yaml > irc_3.log 2> irc_3.err
echo '--- Finished IRC 3 ---'

