#!/bin/bash
#$ -N yarp
#$ -q long
#$ -pe smp 2
#$ -l h_vmem=10000M
#$ -l h_rt=01:00:00
#$ -o /dev/null
#$ -e /dev/null

apptainer exec --bind /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/soumi_calcs/OCC=O/SCRATCH/2409865.289214986_ll_path.gsm:/work --pwd /work /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/containers/erm42_yarp_pysis_xtb.sif bash /work/run_pysis_inner.sh
