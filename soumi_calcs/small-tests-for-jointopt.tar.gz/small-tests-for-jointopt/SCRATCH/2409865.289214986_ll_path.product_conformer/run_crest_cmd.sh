#!/bin/bash
#$ -N yarp
#$ -q long
#$ -pe smp 2
#$ -l h_vmem=10000M
#$ -l h_rt=01:00:00
#$ -o /dev/null
#$ -e /dev/null

cd /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/soumi_calcs/small-tests-for-jointopt/SCRATCH/2409865.289214986_ll_path.product_conformer
apptainer exec --bind /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/soumi_calcs/small-tests-for-jointopt/SCRATCH/2409865.289214986_ll_path.product_conformer:/work --pwd /work /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/containers/erm42_yarp_crest.sif crest input.xyz --gfn -nozs -T 2 --chrg 0 --uhf 0 > crest_run.log 2> crest_run.err
