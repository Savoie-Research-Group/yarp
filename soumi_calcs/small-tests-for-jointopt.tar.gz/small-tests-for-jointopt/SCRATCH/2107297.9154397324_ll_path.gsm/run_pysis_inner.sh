#!/bin/bash

echo 'Starting YARP serial GSM execution...'

echo '--- Running GSM pair 1 ---'
cd /work/gsm_run1
pysis gsm_1_input.yaml > gsm_1.log 2> gsm_1.err
echo '--- Finished GSM pair 1 ---'

echo '--- Running GSM pair 2 ---'
cd /work/gsm_run2
pysis gsm_2_input.yaml > gsm_2.log 2> gsm_2.err
echo '--- Finished GSM pair 2 ---'

echo '--- Running GSM pair 3 ---'
cd /work/gsm_run3
pysis gsm_3_input.yaml > gsm_3.log 2> gsm_3.err
echo '--- Finished GSM pair 3 ---'

