#!/bin/bash
#$ -N yarp
#$ -q long
#$ -pe smp 2
#$ -l h_vmem=10000M
#$ -l h_rt=01:00:00
#$ -o /dev/null
#$ -e /dev/null

cd /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/soumi_calcs/small-tests-for-jointopt/SCRATCH/2409865.289214986_ll_refine.product_optimization
apptainer exec --bind /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/soumi_calcs/small-tests-for-jointopt/SCRATCH/2409865.289214986_ll_refine.product_optimization:/work --pwd /work /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/containers/erm42_yarp_pysis_xtb.sif pysis min_opt.yaml > min_opt.log 2> min_opt.err
