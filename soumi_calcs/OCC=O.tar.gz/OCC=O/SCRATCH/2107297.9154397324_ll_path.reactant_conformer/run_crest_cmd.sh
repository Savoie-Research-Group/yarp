#!/bin/bash
#$ -N yarp
#$ -q long
#$ -pe smp 2
#$ -l h_vmem=10000M
#$ -l h_rt=01:00:00
#$ -o /dev/null
#$ -e /dev/null

cd /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/soumi_calcs/OCC=O/SCRATCH/2107297.9154397324_ll_path.reactant_conformer
apptainer exec --bind /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/soumi_calcs/OCC=O/SCRATCH/2107297.9154397324_ll_path.reactant_conformer:/work --pwd /work /users/shaldar/afs-backups/Apps/yarp-again-fixed-JO/yarp-again/containers/erm42_yarp_crest.sif crest input.xyz --gfn -nozs -T 2 --chrg 0 --uhf 0 > crest_run.log 2> crest_run.err
